
import React from 'react';

const AnimatedBackground: React.FC = () => {
  return <div className="animated-gradient-background" />;
};

export default AnimatedBackground;
